////////////////////////////////////////////////////////////////////////////////
//
//  TCAP Server -- Test Program for PegCounters
//  
//

#include <its++.h>

#include <iostream>

#include <its_app.h>
#include <its_transports.h>
#include <its_iniparse.h>
#include <its_thread.h>
#include <its_semaphore.h>
#include <its_timers.h>

#include <itu/sltm.h>
#include <itu/sccp.h>
#include <itu/tcap.h>
#include <tcap++.h>

//#include <its_statics.cpp>

#include <its_imal_trans.h>
#include <PegCounters.h>

#include <engine++.h>

#if defined(ITS_STD_NAMESPACE)
using namespace std;
using namespace its;

#endif // defined(ITS_STD_NAMESPACE)

#if defined(ITS_NAMESPACE)
using namespace engine;
#endif

//////////////////////////////////////////////////////////////////////////////

//
//  Temporary work around for missing symbols in IntelliNet Vendor Library.
//
//  => Must be removed when problem will be corrected.
//

//////////////////////////////////////////////////////////////////////////////

extern "C" {

//int ISUP_SetVariant_CCITT() { return 0; }
int CCITT_CallTable;
//int CCITT_ISUP_Variant() { return 0; }
int ISUP_TlvEventToL3Message_CCITT() { return 0; }
int ISUP_L3MessageToTlvEvent_CCITT() { return 0; }
int ComputeMSize() { ITS_EVENT ev; SLTM_Encode(&ev, NULL, 0); return 0; }

}

//////////////////////////////////////////////////////////////////////////////

//extern "C" ITS_Class itsINTELLISS7_Class;

//static ATI_TestProc testSuite[maxSizeOfTestSuite];
static ITS_ResourceManager* testSuiteData = NULL; 
static ITS_HANDLE tcap_handle;

////////////////////////////////////////////////////////////////////////////////
//
//  Local function declarations.
//
int  InitializeTestHLR();
void TerminateTestHLR();

void PatsTest1();
void PatsTest2();
void patsWaitOnEvent();
void patsReceiveDialogue();
void patsProcessUni();
void patsProcessBegin();
void patsProcessContinue();
void patsProcessEnd();
void patsProcessNotice();
void patsProcessAbort();
void patsReceiveComponent();
void patsProcessInvoke();
void patsProcessResult();
void patsBuildResult_NL();
void patsProcessError();
void patsProcessReject();
void patsProcessCancel();
void patsBuildContinue();
void patsBuildEnd();
void patsBuildUAbort();
void patsBuildInvoke();
void patsBuildCancel();
void patsBuildResult();
void patsBuildResult_NL();
void patsBuildError();
void patsBuildReject();
void patsPrintCounters();
bool patsSelectBuildResponse();
bool patsSendComponent();
bool patsSendDialogue();
void patsCleanUpDialogue();


#if defined(WIN32)
#define EXPORTFUNC  __declspec(dllexport)
#else
#define EXPORTFUNC
#endif


extern "C" EXPORTFUNC void
WorkerDispatchFunction(ITS_ThreadPoolThread* thr, void* arg);

////////////////////////////////////////////////////////////////////////////////
//
//  Synchronization object (semaphore) used to synchronize primary thread and
//  border transport thread.
//

static ITS_Semaphore borderTransportSemaphore(0);

//#define LOCAL_PC    2
//#define LOCAL_SSN   6

//#define REMOTE_PC   1
//#define REMOTE_SSN  3



ITS_OCTET group;
//#define TBLgrp(tid,n) typedef struct { unsigned char id; char *pname;} TAGTBL; TAGTBL grptbl_##tid[n+1] = { 

typedef struct { unsigned char id; char *pname;} TAGTBL, *PTAGTBL;

#define TBLgrp(tid,n) struct { unsigned char id; char *pname;} grptbl_##tid[n+1] = { 
#define TBLent(X, Y) X, Y,
#define TBLend 0, (char *) -1 }

#define TBLptr(n) struct {void *ptbl;} tblptrs[n+1] = {
#define TBLptrent(X) X,
#define TBLptrend (char *) -1 }


#define REJdef(n) struct { unsigned char type; unsigned char code;}  rejtbl[n+1] = { 
#define REJent(X, Y) X, Y,
#define REJend 0xFF, 0xFF }

#define REASONdef(n) struct { unsigned char reason;}  reasontbl[n+1] = { 
#define REASONent(X) X,
#define REASONend 0xFF }


	REJdef(19)
		REJent (TCAP_PROB_GENERAL_CCITT, TCAP_PROB_SPEC_GEN_UNREC_COMP_CCITT)
		REJent (TCAP_PROB_GENERAL_CCITT, TCAP_PROB_SPEC_GEN_MISTYPED_COMP_CCITT)
		REJent (TCAP_PROB_GENERAL_CCITT, TCAP_PROB_SPEC_GEN_BADLY_STRUCT_COMP_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_DUPLICATE_INV_ID_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_UNREC_OP_CODE_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_MISTYPED_PARAM_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_RESOURCE_LIMIT_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_INITIATE_RELEASE_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_UNREC_LINKED_ID_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_UNEXPECTED_LINK_RESP_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_UNEXPECTED_LINKED_OP_CCITT)
		REJent (TCAP_PROB_RETURN_RES_CCITT, TCAP_PROB_SPEC_RES_UNREC_INVOKE_ID_CCITT)
		REJent (TCAP_PROB_RETURN_RES_CCITT, TCAP_PROB_SPEC_RES_UNEXPECTED_RET_RES_CCITT)
		REJent (TCAP_PROB_RETURN_RES_CCITT, TCAP_PROB_SPEC_RES_MISTYPED_PARAM_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_UNREC_INVOKE_ID_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_UNEXPECTED_RET_ERROR_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_UNREC_ERROR_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_UNEXPECTED_ERROR_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_MISTYPED_PARAM_CCITT)
	REJend;

	REASONdef(3)
		REASONent(TCAP_UABT_AC_NOT_SUP_CCITT)
		REASONent(TCAP_UABT_DLG_REFUSED_CCITT)
		REASONent(TCAP_UABT_USER_DEFINED_CCITT)
	REASONend;



PTAGTBL ptbl;

	theCOUNTERS mytheCounters;
	theCOUNTERS *pmytheCounters=&mytheCounters;
	miscCOUNTERS mymiscCounters;
	miscCOUNTERS *pmymiscCounters=&mymiscCounters;


	TBLgrp(msgGroup,41)
		TBLent(PEG_TOTAL_TCAP_MSGS, "Total All TCAP Messages")	
		TBLent(PEG_TOTAL_SCCP_MSGS, "Total All SCCP Messages")
		TBLent(PEG_TCAP_UNKNOWN_MSG, "TCAP Unknown")
		TBLent(PEG_SCCP_UNKNOWN_MSG, "SCCP Unknown")
		TBLent(TCAP_PT_TC_UNI_CCITT, "(0x61U)  TC-Uni") 
		TBLent(TCAP_PT_TC_BEGIN_CCITT, "(0x62U)  TC-Begin") 
		TBLent(TCAP_PT_TC_END_CCITT, "(0x64U)  TC-End") 
		TBLent(TCAP_PT_TC_CONTINUE_CCITT, "(0x65U)  TC-Continue") 
		TBLent(TCAP_PT_TC_P_ABORT_CCITT, "(0x67U)  TC-P-Abort") 
		TBLent(TCAP_PT_TC_U_ABORT_CCITT, "(0x68U)  TC-U-Abort") 
		TBLent(TCAP_PT_TC_NOTICE_CCITT, "(0x69U)  TC-Notice")
		TBLent(TCAP_PT_TC_UNI_ANSI, "(0xE1U)  TC-Uni") 
		TBLent(TCAP_PT_TC_QUERY_W_PERM_ANSI, "(0xE2U)  TC-Query-WIP") 
		TBLent(TCAP_PT_TC_QUERY_WO_PERM_ANSI, "(0xE3U)  TC-Query-WOP")
		TBLent(TCAP_PT_TC_RESP_ANSI, "(0xE4U)  TC-Resp") 
		TBLent(TCAP_PT_TC_CONV_W_PERM_ANSI, "(0xE5U)  TC-Conv-WIP") 
		TBLent(TCAP_PT_TC_CONV_WO_PERM_ANSI, "(0xE6U)  TC-Conv-WOP") 
		TBLent(TCAP_PT_TC_ABORT_ANSI, "(0xE6U)  TC-Conv-WOP") 
		TBLent(TCAP_PT_TC_NOTICE_ANSI, "(0xE8U)  TC-Notice") 
		TBLent(SCCP_MSG_CR, "(0x01U) Connection Request")
		TBLent(SCCP_MSG_CC, "(0x02U) Conection Confirm")
		TBLent(SCCP_MSG_CREF, "(0x03U) Connection REFused")
		TBLent(SCCP_MSG_RLSD, "(0x04U) ReLeaSed")
		TBLent(SCCP_MSG_RLC, "(0x05U) ReLease Complete")
		TBLent(SCCP_MSG_DT1, "(0x06U) DaTa form 1")
		TBLent(SCCP_MSG_DT2, "(0x07U) DaTa form 2")
		TBLent(SCCP_MSG_AK, "(0x08U) AcKnowledgement")
		TBLent(SCCP_MSG_UDT, "(0x09U) Unit DaTa")
		TBLent(SCCP_MSG_UDTS, "(0x0AU) Unit DaTa Service")
		TBLent(SCCP_MSG_ED, "(0x0BU) Expedited Data")
		TBLent(SCCP_MSG_EA, "(0x0CU) Expedited data Acknowledgement")
		TBLent(SCCP_MSG_RSR, "(0x0DU) ReSet Request")
		TBLent(SCCP_MSG_RSC, "(0x0EU) ReSet Confirmation")
		TBLent(SCCP_MSG_ERR, "(0x0FU) ERRor")
		TBLent(SCCP_MSG_IT, "(0x10U) Inactivity Test")
		TBLent(SCCP_MSG_XUDT, "(0x11U) eXtended Unit DaTa")
		TBLent(SCCP_MSG_XUDTS, "(0x12U) eXtended Unit DaTa Service")
		TBLent(SCCP_MSG_LUDT, "(0x13U) Long Unitdata message")
		TBLent(SCCP_MSG_LUDTS, "(0x14U) Long Unitdata Service Msg")
		TBLent(SCCP_MSG_NOTICE, "(0xFFU) Notice from MTP3/to user")
	TBLend;

	TBLgrp(scmgGroup,13)
		TBLent(PEG_TOTAL_SCMG_MSGS, "Total All SCMG Messages")
		TBLent(PEG_SCMG_UNKNOWN_MSG, "SCMG Unknown")
		TBLent(SCCP_SCMG_SS_ALLOWED, "(0x01U) SubSystem Allowed")
		TBLent(SCCP_SCMG_SS_PROHIBIT, "(0x02U) SubSystem Prohibited")
		TBLent(SCCP_SCMG_SS_STATUS_TEST, "(0x03U) SubSystem Status Test")
		TBLent(SCCP_SCMG_SS_OOS_REQ, "(0x04U) SubSystem Out Of Service Request")
		TBLent(SCCP_SCMG_SS_OOS_GRANT, "(0x05U) SubSystem Out Of Service Grant")
		TBLent(SCCP_SCMG_SS_BACKUP_ROUTE, "(0xFDU) SubSystem Backup Routing")
		TBLent(SCCP_SCMG_SS_NORMAL_ROUTE, "(0xFEU) SubSystem  Normal Routing")
		TBLent(SCCP_SCMG_SS_ROUTE_STATUS, "(0xFFU) SubSystem Route Status")  
		TBLent(SCCP_SCMG_SS_UIS, "(0xF0U)	  User In Service")
		TBLent(SCCP_SCMG_SS_UOS, "(0xF1U)   User Out of Service")
		TBLent(SCCP_SCMG_SS_CONG, "(0xF2U)	  User Congested")
	TBLend;


	TBLgrp(cptGroup,19)
		TBLent(PEG_TOTAL_CMPS,"Total All Components")
		TBLent(TCAP_PT_TC_INVOKE_CCITT, "(0xA1U)  TC-Invoke") 
		TBLent(TCAP_PT_TC_RESULT_L_CCITT, "(0xA2U)  TC-Result-L")
		TBLent(TCAP_PT_TC_U_ERROR_CCITT, "(0xA3U)  TC-U-Error") 
		TBLent(TCAP_PT_TC_R_REJECT_CCITT, "(0xA4U)  TC-R-Reject") 
		TBLent(TCAP_PT_TC_RESULT_NL_CCITT, "(0xA7U)  TC-Result-NL") 
		TBLent(TCAP_PT_TC_L_CANCEL_CCITT, "(0xA8U)  TC-L-Cancel") 
		TBLent(TCAP_PT_TC_U_CANCEL_CCITT, "(0xA9U)  TC-U-Cancel") 
		TBLent(TCAP_PT_TC_L_REJECT_CCITT, "(0xAAU)  TC-L-Reject") 
		TBLent(TCAP_PT_TC_U_REJECT_CCITT, "(0xABU)  TC-U-Reject") 
		TBLent(TCAP_PT_TC_TIMER_RESET_CCITT, "(0xACU)  TC-Timer-Reset") 
		TBLent(TCAP_PT_TC_INVOKE_ANSI, "(0xE9U)  TC-Invoke-L")
		TBLent(TCAP_PT_TC_RESULT_L_ANSI, "(0xEAU)  TC-Result-L")
		TBLent(TCAP_PT_TC_ERROR_ANSI, "(0xEBU)  TC-Error") 
		TBLent(TCAP_PT_TC_REJECT_ANSI, "(0xECU)  TC-Reject") 
		TBLent(TCAP_PT_TC_INVOKE_NL_ANSI, "(0xEDU)  TC-Invoke-NL")
		TBLent(TCAP_PT_TC_RESULT_NL_ANSI, "(0xEEU)  TC-Result-NL :") 
		TBLent(TCAP_PT_TC_CANCEL_ANSI, "(0xEFU) this doesn't exist but several vendors use it")
	TBLend;


	TBLgrp(reasonABTGroup,0)
	TBLend;


	TBLgrp(reasonUABTGroup,3)
		TBLent(TCAP_UABT_AC_NOT_SUP_CCITT, "1 - Application context not supported")
		TBLent(TCAP_UABT_DLG_REFUSED_CCITT, "2 - Dialogue refused")
		TBLent(TCAP_UABT_USER_DEFINED_CCITT, "3 - User defined")
	TBLend;

	TBLgrp(reasonPABTGroup,7)
		TBLent(TCAP_ABT_REASON_UNREC_MSG_TYPE_CCITT, "(0x00U) UNREC_MSG_TYPE")
		TBLent(TCAP_ABT_REASON_UNREC_TRANS_ID_CCITT, "(0x01U) UNREC_TRANS_ID")
		TBLent(TCAP_ABT_REASON_BADLY_STRUCT_TRANS_PORT_CCITT, "(0x02U) BADLY_STRUCT_TRANS_PORT")
		TBLent(TCAP_ABT_REASON_INCORRECT_TRANS_PORT_CCITT, "(0x03U) INCORRECT_TRANS_PORT")
		TBLent(TCAP_ABT_REASON_RES_UNAVAIL_CCITT, "(0x04U) RES_UNAVAIL")
		TBLent(TCAP_PABT_ABNORMAL_DLG_CCITT, "(126) ABNORMAL_DLG")
		TBLent(TCAP_PABT_NO_COMMON_DLG_CCITT, "(127) NO_COMMON_DLG")
	TBLend;

	TBLgrp(rejCodeResGroup,3)
		TBLent(TCAP_PROB_SPEC_RES_UNREC_INVOKE_ID_CCITT, "(0x00U) RES_UNREC_INVOKE_ID")
		TBLent(TCAP_PROB_SPEC_RES_UNEXPECTED_RET_RES_CCITT, "(0x01U) RES_UNEXPECTED_RET_RES")
		TBLent(TCAP_PROB_SPEC_RES_MISTYPED_PARAM_CCITT, "(0x02U) RES_MISTYPED_PARAM")
	TBLend;

	TBLgrp(rejCodeGenGroup,3)
		TBLent(TCAP_PROB_SPEC_GEN_UNREC_COMP_CCITT, "(0x00U) GEN_UNREC_COMP")
		TBLent(TCAP_PROB_SPEC_GEN_MISTYPED_COMP_CCITT, "(0x01U) GEN_MISTYPED_COMP")
		TBLent(TCAP_PROB_SPEC_GEN_BADLY_STRUCT_COMP_CCITT, "(0x02U) GEN_BADLY_STRUCT_COMP")
	TBLend;

	TBLgrp(rejCodeInvGroup,8)
		TBLent(TCAP_PROB_SPEC_INV_DUPLICATE_INV_ID_CCITT, "(0x00U) INV_DUPLICATE_INV_ID")
		TBLent(TCAP_PROB_SPEC_INV_UNREC_OP_CODE_CCITT, " (0x01U) INV_UNREC_OP_CODE")
		TBLent(TCAP_PROB_SPEC_INV_MISTYPED_PARAM_CCITT, "(0x02U) INV_MISTYPED_PARAM")
		TBLent(TCAP_PROB_SPEC_INV_RESOURCE_LIMIT_CCITT, "(0x03U) INV_RESOURCE_LIMIT")
		TBLent(TCAP_PROB_SPEC_INV_INITIATE_RELEASE_CCITT, "(0x04U) INV_INITIATE_RELEASE")
		TBLent(TCAP_PROB_SPEC_INV_UNREC_LINKED_ID_CCITT, "(0x05U) INV_UNREC_LINKED_ID")
		TBLent(TCAP_PROB_SPEC_INV_UNEXPECTED_LINK_RESP_CCITT, "(0x06U) INV_UNEXPECTED_LINK_RESP")
		TBLent(TCAP_PROB_SPEC_INV_UNEXPECTED_LINKED_OP_CCITT, "(0x07U) INV_UNEXPECTED_LINKED_OP")
	TBLend;


	TBLgrp(rejCodeErrGroup,5)
		TBLent(TCAP_PROB_SPEC_ERR_UNREC_INVOKE_ID_CCITT, "(0x00U) ERR_UNREC_INVOKE_ID")
		TBLent(TCAP_PROB_SPEC_ERR_UNEXPECTED_RET_ERROR_CCITT, "(0x01U) ERR_UNEXPECTED_RET_ERROR")
		TBLent(TCAP_PROB_SPEC_ERR_UNREC_ERROR_CCITT, "(0x02U) ERR_UNREC_ERROR")
		TBLent(TCAP_PROB_SPEC_ERR_UNEXPECTED_ERROR_CCITT, "(0x03U) ERR_UNEXPECTED_ERROR")
		TBLent(TCAP_PROB_SPEC_ERR_MISTYPED_PARAM_CCITT, "(0x04U) ERR_MISTYPED_PARAM")
	TBLend;


	TBLgrp(rejCodeTransGroup,0)
	TBLend;


	TBLgrp(miscGroup,66)
		TBLent(PEG_TCAP_ACTIVE_DIALOGUE, "TCAP_ACTIVE_DIALOGUE")
		TBLent(PEG_TCAP_ACTIVATED_DIALOGUE, "TCAP_ACTIVATED_DIALOGUE")
		TBLent(PEG_TCAP_ACTIVE_TRANSACTIONS, "TCAP_ACTIVE_TRANSACTIONS")
		TBLent(PEG_TCAP_ACTIVATED_TRANSACTIONS, "TCAP_ACTIVATED_TRANSACTIONS")
		TBLent(PEG_TCAP_INV_CLASS_1_SENT, "TCAP_INV_CLASS_1 SENT")
		TBLent(PEG_TCAP_INV_CLASS_2_SENT, "TCAP_INV_CLASS_2 SENT")
		TBLent(PEG_TCAP_INV_CLASS_3_SENT, "TCAP_INV_CLASS_3 SENT")
		TBLent(PEG_TCAP_INV_CLASS_4_SENT, "TCAP_INV_CLASS_4 SENT")
		TBLent(PEG_TCAP_INV_CONTEXT, "TCAP_INV_CONTEXT")
		TBLent(PEG_TCAP_INV_CONTEXT_ACTIVE, "TCAP_INV_CONTEXT_ACTIVE")
		TBLent(PEG_TCAP_SEND_DIALOGUE, "TCAP_SEND_DIALOGUE")
		TBLent(PEG_TCAP_RECEIVE_DIALOGUE, "TCAP_RECEIVE_DIALOGUE")
		TBLent(PEG_TCAP_SEND_COMPONENT, "TCAP_SEND_COMPONENT")
		TBLent(PEG_TCAP_RECEIVE_COMPONENT, "TCAP_RECEIVE_COMPONENT")
		TBLent(PEG_TCAP_RECEIVE_UDT, "TCAP_RECEIVE_UDT")
		TBLent(PEG_TCAP_RECEIVE_XUDT, "TCAP_RECEIVE_XUDT")
		TBLent(PEG_TCAP_RECEIVE_UDTS, "TCAP_RECEIVE_UDTS")
		TBLent(PEG_TCAP_RECEIVE_XUDTS, "TCAP_RECEIVE_XUDTS")
		TBLent(PEG_TCAP_RECEIVE_INVALID_SCCP, "TCAP_RECEIVE_INVALID_SCCP")
		TBLent(PEG_TCAP_SEND_UDT, "TCAP_SEND_UDT")
		TBLent(PEG_TCAP_SEND_XUDT, "TCAP_SEND_XUDT")
		TBLent(PEG_TCAP_SEND_UDTS, "TCAP_SEND_UDTS")
		TBLent(PEG_TCAP_SEND_XUDTS, "TCAP_SEND_XUDTS")
		TBLent(PEG_TCAP_PREARRANGED_END, "TCAP_PREARRANGED_END")
		TBLent(PEG_TCAP_SCCP_CLASS_0_SENT, "TCAP_SCCP_CLASS_0_SENT")
		TBLent(PEG_TCAP_SCCP_CLASS_1_SENT, "TCAP_SCCP_CLASS_1_SENT")
		TBLent(PEG_TCAP_SCCP_CLASS_0_RECEIVED, "TCAP_SCCP_CLASS_0_RECEIVED")
		TBLent(PEG_TCAP_SCCP_CLASS_1_RECEIVED, "TCAP_SCCP_CLASS_1_RECEIVED")
		TBLent(PEG_TCAP_SCCP_RET_ON_ERR_SENT, "TCAP_SENT_WITH_RET_ON_ERR_SET")
		TBLent(PEG_MTP3_MSG_PAUSE, "MTP3_MSG_PAUSE")
		TBLent(PEG_MTP3_MSG_RESUME, "MTP3_MSG_RESUME")
		TBLent(PEG_MTP3_MSG_STATUS, "MTP3_MSG_STATUS")
		TBLent(PEG_SCCP_ACTIVE_CONNECTION, "SCCP_ACTIVE_CONNECTION")		
		TBLent(PEG_SCCP_ACTIVATED_CONNECTION, "SCCP_ACTIVATED_CONNECTION")	
		TBLent(PEG_SCCP_MSG_FOR_PROHIBITED_SSN, "SCCP_MSG_FOR_PROHIBITED_SSN")						
		TBLent(PEG_SCCP_USER_INTERVENTION, "SCCP_USER_INTERVENTION")		
		TBLent(PEG_SCCP_USER_SEND_EVENT, "SCCP_USER_SEND_EVENT")		
		TBLent(PEG_SCCP_USER_RECEIVE_EVENT, "SCCP_USER_RECEIVE_EVENT")		
		TBLent(PEG_SCCP_SEND_USER_OUT_OF_SERVICE, "SCCP_SEND_USER_OUT_OF_SERVICE")	
		TBLent(PEG_SCCP_SEND_USER_IN_SERVICE, "SCCP_SEND_USER_IN_SERVICE")	
		TBLent(PEG_SCCP_SEND_USER_CONGESTED, "SCCP_SEND_USER_CONGESTED")	
		TBLent(PEG_SCCP_ROUTING_FAILURE, "SCCP_ROUTING_FAILURE")		
		TBLent(PEG_SCCP_LBC_SS_IN_SERVICE, "SCCP_LBC_SS_IN_SERVICE")		
		TBLent(PEG_SCCP_LBC_SS_OUT_OF_SERVICE, "SCCP_LBC_SS_OUT_OF_SERVICE")	
		TBLent(PEG_SCCP_LBC_SS_CONGESTED, "SCCP_LBC_SS_CONGESTED")		
		TBLent(PEG_SCCP_LBC_SS_ALLOWED, "SCCP_LBC_SS_ALLOWED")			
		TBLent(PEG_SCCP_LBC_SS_PROHIBITED, "SCCP_LBC_SS_PROHIBITED")		
		TBLent(PEG_SCCP_LBC_USER_IN_SERVICE, "SCCP_LBC_USER_IN_SERVICE")	
		TBLent(PEG_SCCP_LBC_USER_OUT_OF_SERVICE, "SCCP_LBC_USER_OUT_OF_SERVICE")	
		TBLent(PEG_SCCP_GTT_REQUEST, "SCCP_GTT_REQUEST")
		TBLent(PEG_SCCP_GTT_SUCCESS, "SCCP_GTT_SUCCESS")
		TBLent(PEG_SCCP_GTT_FAILURE, "SCCP_GTT_FAILURE")
		TBLent(PEG_SCCP_PCLASS_0_SENT, "SCCP_PCLASS_0_SENT")
		TBLent(PEG_SCCP_PCLASS_1_SENT, "SCCP_PCLASS_1_SENT")
		TBLent(PEG_SCCP_PCLASS_2_SENT, "SCCP_PCLASS_2_SENT")
		TBLent(PEG_SCCP_PCLASS_3_SENT, "SCCP_PCLASS_3_SENT")
		TBLent(PEG_SCCP_PCLASS_0_RECEIVED, "SCCP_PCLASS_0_RECEIVED")
		TBLent(PEG_SCCP_PCLASS_1_RECEIVED, "SCCP_PCLASS_0_RECEIVED")
		TBLent(PEG_SCCP_PCLASS_2_RECEIVED, "SCCP_PCLASS_0_RECEIVED")
		TBLent(PEG_SCCP_PCLASS_3_RECEIVED, "SCCP_PCLASS_0_RECEIVED")
		TBLent(PEG_SCCP_RET_ON_ERR_SENT, "SCCP_RET_ON_ERR_SENT")
		TBLent(PEG_SCCP_RET_ON_ERR_RECEIVED, "SCCP_RET_ON_ERR_RECEIVED")


		TBLent(PEG_MISC_UNUSED, "Unused - for testing")
	TBLend;



	TBLptr(13)
		TBLptrent(0)
		TBLptrent(grptbl_msgGroup)
		TBLptrent(grptbl_scmgGroup)
		TBLptrent(grptbl_cptGroup)
		TBLptrent(grptbl_reasonABTGroup)
		TBLptrent(grptbl_reasonUABTGroup)
		TBLptrent(grptbl_reasonPABTGroup)
		TBLptrent(grptbl_rejCodeResGroup)
		TBLptrent(grptbl_rejCodeGenGroup)
		TBLptrent(grptbl_rejCodeInvGroup)
		TBLptrent(grptbl_rejCodeErrGroup)
		TBLptrent(grptbl_rejCodeTransGroup)
		TBLptrent(grptbl_miscGroup)
	TBLptrend;


//
// Possible return Cause if application receives a TC_Notice.
//
static char *notice_returnCause[] = 
{
    "No Translation for an Address of Such Nature",
    "No Translation for this Specific Address",
    "Subsystem Congestion",
    "Subsystem Failure",
    "Unequipped User",
    "MTP Failure",
    "Network Congestion",
    "Error in Message Transport (XUDTS msg)",
    "Error in Local Processing (XUDTS msg)",
    "Destination Cannot Perform Reassembly (XUDTS msg)",
    "SCCP Failure",
};

static char *abort_pabortReason[] = 
{
	"Unrecognized message type",
	"Unrecognized transaction id",
	"Badly structured transaction portion",
	"Incorrect transaction portion",
	"Ressources unavailable",
};



int
main(int argc, const char **argv)
{    
    ENGINE_Initialize(argc, argv, NULL, 0);

    ENGINE_Run(argc, argv);

    return (0);
}


//
// This method will initialize the test Server
// o Add IntelliNet SS7 Stack feature.
// o Initialize IntelliSS7 Subsytems
//

int
InitializeTestHLR()
{

	return (0);
}


void
TerminateTestHLR()
{
	cout << endl << " *** Test Server is quiting ... " << endl;

	TIMERS_Sleep(2);


	ITS_Terminate(tcap_handle);

	if (testSuiteData)
	{
		delete testSuiteData;
	}

	ITS_RemFeature(itsIMAL_Class);
    ITS_RemFeature(itsKEEPALIVE_Class);
    ITS_RemFeature(itsINTELLISS7_Class);

	ITS_GlobalStop();
}



///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
//  FROM THE FILE test_sim_Server_suite_imap.cpp
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
//
//  Local function declarations.
//



//
//  Macro to get the size (count of items) of a fixed array.
//
#define FixedArraySize(array)       \
    (sizeof(array) / sizeof(array[0]))

//
//  Macro to convert fixed arrays (of bytes) to vectors.
//
#define FixedByteArrayToVector(array)   \
    (vector<byte>(array, array + FixedArraySize(array)))






//
// MTP3 callbak function
//
void
MTP3StateHandler(ITS_POINTER object, ITS_POINTER userData,
                 ITS_POINTER callData)
{
    ITS_EVENT* event = (ITS_EVENT*)callData;

    if(event ->data[0] == MTP3_MSG_RESUME)
    {
        //
        // The link between the Gateway and the Application is up.
        // Application can send messages. They will be transmitted (unless
        // error. Function could notify application via global variable, etc
        //
        cout <<" Received an MTP3 RESUME Status Indication" << endl;
    }
    else if(event ->data[0] == MTP3_MSG_PAUSE)
    {
        //
        // The link between the Gateway and the Application is down.
        // There is no point for the application to send messages, they will
        // not be transmitted. Function could notify application via global
        //  variable, etc
        //
        cout <<" Received an MTP3 PAUSE Status Indication" << endl;
    }
}



///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////

extern "C" EXPORTFUNC int 
IMALServerPreInit(ThreadPoolThread *thr)
{
    cout << "IMALServerPreInit called" << endl;

    return (ITS_SUCCESS);
}

extern "C" EXPORTFUNC int 
IMALServerPostInit(ThreadPoolThread *thr, ITS_HANDLE handle)
{
    ITS_Worker* work = (ITS_Worker *)thr;

    cout << "IMALServerPostInit called" << endl;

    if (handle == NULL)
    {
        cout << "IMAL server cannot be initialized, check the IPs" << endl;
    }

    ITS_ASSERT(handle != NULL);

    // To signal primary thread that the border transport thread is running and
    // that the associated transport is initialized.

    borderTransportSemaphore.Post();                   
          
    return ITS_SUCCESS;
}

extern "C" EXPORTFUNC int 
IMALServerPreNext(ThreadPoolThread *thr)
{
    cout << "IMALServerPreNext called" << endl;

    return (ITS_SUCCESS);
}

extern "C" EXPORTFUNC bool 
IMALServerNextEventFailed(ThreadPoolThread *thr, int ret)
{
    cout << "IMALServerNextEventFailed called" << endl;

    cout << "IMAL Server Transport Failure" << endl;

    ITS_Error itsError(ret, __FILE__, __LINE__);

    cout << endl << itsError.GetDescription() << endl;
    
    if (ret == ITS_ERCVFAIL)
    {
        return true;
    }
    else
    {
        return false;
    }    
}

extern "C" EXPORTFUNC int 
IMALServerPostNext(ThreadPoolThread *thr, Event &event)
{
    ITS_UINT ret = ITS_SUCCESS;

    cout << "IMALServerPostNext called" << endl;

    ITS_Worker* work = (ITS_Worker *)thr;

    cout << "Received event (source = " << event.GetSource() 
          << ") on IMALServer" << endl;

    // Set event source to MTP3 (for routing purpose).

    //event.SetSource(ITS_MTP3_SRC);

	// Send event to IntelliNet stack (SCCP layer).
    
    //ITS_Transport::PutEvent(ITS_SCCP_SRC, event);
    
    return ITS_SUCCESS;
}

extern "C" EXPORTFUNC int 
IMALServerUserMsgHandler(ThreadPoolThread *thr, Event &event)
{
    cout << "IMALServerUserMsgHandler called" << endl;

    return (ITS_SUCCESS);
}

extern "C" EXPORTFUNC int 
IMALServerSCCPMsgHandler(ThreadPoolThread *thr, Event &event)
{
    int ret = ITS_SUCCESS;

    cout << "IMALServerSCCPMsgHandler called" << endl;

    //Even if ret is a failure.. so that the thread doesn't exit 
    //in the SS7 Dispatcher

    return (ITS_SUCCESS);
}

extern "C" EXPORTFUNC int 
IMALServerISUPMsgHandler(ThreadPoolThread *thr, Event &ev)
{
    cout << "IMALServerISUPMsgHandler called" << endl;

    return (ITS_SUCCESS);
}

extern "C" EXPORTFUNC void 
IMALServerPreTerm(ThreadPoolThread *thr)
{
     cout << "IMALServerPreTerm called" << endl;

     cout << "Exiting function IMALServerTransportFunction normally" << endl;
}

extern "C" EXPORTFUNC void 
IMALServerPostTerm(ThreadPoolThread *thr)
{
    cout << "IMALServerPreTerm called" << endl;

    ITS_Worker* work = static_cast<ITS_Worker*> (thr);

	borderTransportSemaphore.Post();
}


extern "C" EXPORTFUNC void
HLRPreFunc()
{

    cout << "Server PreFunc called" << endl;

    its::ThreadPoolEntry thr;
 
    workerPool->GetFirstAvailThread(thr);
    workerPool->DispatchOnThread(thr, WorkerDispatchFunction,
                                 NULL);

	int numberOfTests = InitializeTestHLR();
    
    return;
}

extern "C" EXPORTFUNC void
HLRPostFunc()
{
    cout << "Server PostFunc called" << endl;
	
    TerminateTestHLR();

    return;
}
	ITS_OCTET AddressIndicatorOrig = 0;
	ITS_OCTET AddressIndicatorDest = 0;
	ITS_UINT pcOrig = 0, pcDest = 0;
	ITS_OCTET ssnOrig = 0, ssnDest = 0;
	ITS_OCTET gttInfoOrig = NULL, gttInfoDest = NULL ;
	ITS_USHORT gttLenOrig = 0, gttLenDest = 0;


	bool stop = false;
	ITS_USHORT dialogue_id = 0;

	ITS_LONG recOperation = 0;
	ITS_LONG sntOperation = 1;
	ITS_LONG saveOperation = 0;
	ITS_OCTET recInvoke_id = 0;
	ITS_OCTET sntInvoke_id = 1;
	ITS_OCTET saveInvoke_id = 0;
	ITS_OCTET recType = 0;
	ITS_OCTET sntType = 0;
	ITS_OCTET recCode = 0;
	ITS_OCTET sntCode = 0;
	ITS_OCTET recClass = 0;
	ITS_OCTET sntClass = 0;
	ITS_OCTET recErrorCode = 0;
	ITS_OCTET sntErrorCode = 1;
	ITS_OCTET recReason = 0;
	ITS_OCTET sntReason = 1;


	string recErrorTxt;
	string sntErrorTxt;
	vector<byte> recParm;
	vector<byte> sntParm;
	std::vector<byte> recAppContext;
	std::vector<byte> sntAppContext;
	ITS_OCTET operationClass = 1;
	ITS_UINT reasonIndex = 1;
	ITS_UINT rejIndex = 1;
	ITS_UINT respCtr = 1;

	ITS_UINT sntBegCtr = 0, sntContCtr = 0, sntEndCtr = 0, sntUAbortCtr = 0, sntNotCtr = 0;
	ITS_UINT recBegCtr = 0, recContCtr = 0, recEndCtr = 0, recUAbortCtr = 0, recNotCtr = 0;
	ITS_UINT sntInvCtr = 0, sntResCtr = 0, sntErrCtr = 0, sntRejCtr = 0, sntResNLCtr = 0;
	ITS_UINT recInvCtr = 0, recResCtr = 0, recErrCtr = 0, recRejCtr = 0, recResNLCtr = 0;
	ITS_UINT recUniCtr = 0, sntUniCtr = 0, recCanCtr = 0, sntCanCtr = 0;

	bool uniRec = false;
	bool manualMode = false;
	bool notLast = false;

////////////////////////////////////////////////////////////////////////////////
//
//  Define Class
//
	TCAP_Dialogue*  pRecvDialogue      = NULL;
	TCAP_Component* pRecvComponent      = NULL;

	TCAP_Dialogue *pTC_Dialogue;
	TCAP_Unidirectional TC_Uni, *pTC_Uni;
	TCAP_Begin TC_Begin, *pTC_Begin;
	TCAP_Continue TC_Continue, *pTC_Continue;
	TCAP_End TC_End, *pTC_End;
	TCAP_Abort TC_Abort, *pTC_Abort;
	TCAP_Notice TC_Notice, *pTC_Notice;

	TCAP_Component *pTC_Component;
	TCAP_Invoke TC_Invoke, *pTC_Invoke;
	TCAP_Result TC_Result, *pTC_Result;
	TCAP_Result TC_Result_NL(false), *pTC_Result_NL;
	TCAP_Error TC_Error, *pTC_Error;
	TCAP_Reject TC_Reject, *pTC_Reject;
	TCAP_Cancel TC_Cancel, *pTC_Cancel;

	ITS_Event event;



extern "C" EXPORTFUNC void
WorkerDispatchFunction(ITS_ThreadPoolThread* thr, void* arg)
{
    //PerformTest(int numOfTests);
//    PerformTest(1);

	////////////////////////////////////////////////////////////////////////
    //
    //  Create transport.
    //

//    tcap_handle = ITS_Initialize(ITS_TCAP | ITS_TRANSPORT_SINGLE_USER |
//								 ITS_TRANSPORT_TQUEUE, 1);
      tcap_handle = ITS_Initialize(ITS_TCAP | ITS_TRANSPORT_TQUEUE, 1);

    if (tcap_handle == NULL)
    {
        // Fatal error.
		cout <<"Failed to Initialize main module...";
        return ;
    } /* if */

		bool done = false;
		while (!done)
		{
			int selection;
			cout << "Enter Selection" << endl
				 << "		1.	Auto Test" << endl
				 << "		2.	Mamual Test" << endl
				 << "		3.	Print Counters" << endl
				 << "		4.	Exit" << endl << endl
				 << "> " << endl;
			cin >> selection;
			switch (selection)
			{
				case 1:
					PatsTest1();
					break;
				case 2:
					manualMode = true;
					PatsTest2();
					manualMode = false;
					break;
				case 3:
					patsPrintCounters();
					break;
				case 4:
					patsPrintCounters();
					done = true;
				default:
					cout << "**** Incorrect Selection ****" << endl << endl;
			} /* switch */
		} /* while */



} /* WorkerDispatchFunction */

void
PatsTest1()
{
	while (true)
	{
		cout << "[Server] About to Wait On Event " << endl;

		patsWaitOnEvent();

		if (!uniRec)
		{
			cout << "[Server] About to Build a Response " << endl;

			if (!patsSelectBuildResponse())
			{
				return;
			} /* if */
			if(!patsSendDialogue())
			{
				return;
			} /* if */
		} /* if */
		else
		{
			uniRec = false;
		} /* else */

		TIMERS_Sleep(5);

		cout << "[Server] ****** Response Sent ****** " << endl;

		patsPrintCounters();
		cout << "Reset Peg Counters" << endl;
		PegCountersReset();
		cout << "Reset Local Counters" << endl;
		sntBegCtr = sntContCtr = sntEndCtr = sntUAbortCtr = sntNotCtr = 0;
		recBegCtr = recContCtr = recEndCtr = recUAbortCtr = recNotCtr = 0;
		sntInvCtr = sntResCtr = sntResNLCtr = sntErrCtr = sntRejCtr = 0;
		recInvCtr = recResCtr = recResNLCtr = recErrCtr = recRejCtr = 0;
		cout << "Counters Reset" << endl;

	} /* while */

	return;
} /* PatsTest1 */

void
PatsTest2()
{	
	bool done = false;
		cout << "[Server] About to Wait On Event " << endl;

		patsWaitOnEvent();

		while (!done)
	{


		char selection = NULL;

		cout << "Select Response" << endl;
		cout << "		C.	Build Continue" << endl
			 << "		E.	Build End" << endl
			 << "		A.	Build UAbort" << endl;
		cout << "		I.	Build Invoke" << endl;
		cout << "		L.	Build Result" << endl;
		cout << "		N.	Build Result NL" << endl;
		cout << "		O.	Build Error" << endl;
		cout << "		J	Build Reject" << endl;
		cout << "		M.	Send Component" << endl;
		cout << "		D.	Send Dialogue" << endl;
		cout << "		*.	CleanUp Dialogue" << endl;
		cout << "		-.	Build & Send Cancel" << endl;
		cout << "		P.	Print Counters" << endl
			 << "		S.	Reset Counters" << endl
			 << "		X.	Exit" << endl 
			 << "		W.	Wait On Events" << endl 
			 << endl;

			cin >> selection;
			selection = tolower(selection);
			switch (selection)
			{
				case 'c':
					patsBuildContinue();
					break;
				case 'e':
					patsBuildEnd();
					break;
				case 'a':
					patsBuildUAbort();
					break;
				case 'i':
					patsBuildInvoke();
					break;
				case 'l':
					patsBuildResult();
					break;
				case 'n':
					patsBuildResult_NL();
					break;
				case 'o':
					patsBuildError();
					break;
				case 'j':
					patsBuildReject();
					break;
				case 'm':
					patsSendComponent();
					break;
				case 'd':
					patsSendDialogue();
					if (!notLast)
					{
						cout << "[Server] About to Wait On Event " << endl;

						patsWaitOnEvent();
					} /* if */
					break;
				case 'u':
					patsCleanUpDialogue();
					break;
				case '-':
					patsBuildCancel();
					patsSendComponent();
					break;
				case 'p':
					patsPrintCounters();
					break;
				case 's':
					PegCountersReset();
					sntBegCtr = sntContCtr = sntEndCtr = sntUAbortCtr = sntNotCtr = 0;
					recBegCtr = recContCtr = recEndCtr = recUAbortCtr = recNotCtr = 0;
					sntInvCtr = sntResCtr = sntResNLCtr =  sntErrCtr = sntRejCtr = 0;
					recInvCtr = recResCtr = recResNLCtr = recErrCtr = recRejCtr = 0;
					sntUniCtr = 0, recUniCtr = 0;
					break;
				case 'x':
					return;
				case 'w':
					patsWaitOnEvent();
					break;
				default:
					cout << "**** Incorrect Selection ****" << endl << endl;
			} /* switch */


		} /* while */



} /* PatsTest2 */


bool
patsSelectBuildResponse()
{

	pTC_Component = NULL;
	pTC_Dialogue = NULL;
// Some of the responses below are not valid sequences of components
	switch (respCtr%11)
	{
		case (0):
			cout << "[Server] Response is Case 0" << endl;
			patsBuildContinue();
			patsBuildInvoke();
			if (!patsSendComponent())
			{
				return (false);
			} /* if */

			patsBuildResult();
			break;
		case (1):
			cout << "[Server] Response is Case 1" << endl;
			patsBuildContinue();
			patsBuildReject();
			break;
		case (2):
			cout << "[Server] Response is Case 2" << endl;
			patsBuildContinue();

			patsBuildResult();
			if (!patsSendComponent())
			{
				return (false);
			} /* if */
			patsBuildReject();
			break;
		case (3):
			cout << "[Server] Response is Case 3" << endl;
			patsBuildContinue();

			patsBuildResult();
			if (!patsSendComponent())
			{
				return (false);
			} /* if */
			patsBuildError();
			break;
		case (4):
			cout << "[Server] Response is Case 4" << endl;
			patsBuildEnd();
			patsBuildError();
			break;
		case (5):
			cout << "[Server] Response is Case 5" << endl;
			patsBuildEnd();
			patsBuildReject();
			break;
		case (6):
			cout << "[Server] Response is Case 6" << endl;
			patsBuildError();
			patsBuildContinue();
			break;
		case (7):
			cout << "[Server] Response is Case 7" << endl;
			patsBuildContinue();
			patsBuildReject();
			break;
		case (8):
			cout << "[Server] Response is Case 8" << endl;
			patsBuildEnd();
			break;
		case (9):
			cout << "[Server] Response is Case 9" << endl;
			patsBuildUAbort();
			break;
		case (10):
			cout << "[Server] Response is Case 10" << endl;
			patsBuildEnd();
			patsBuildInvoke();
			if (!patsSendComponent())
			{
				return (false);
			} /* if */
			patsBuildResult();
			break;

	} /* switch */

	respCtr++;

	if (!patsSendComponent())
	{
		return (false);
	} /* if */

	return (true);
} /* patsSelectBuildResponse */






void
patsWaitOnEvent()
{

	int result = ITS_SUCCESS;

	stop = false;
	dialogue_id = 0;
	pRecvDialogue = NULL;
	pRecvComponent = NULL;
	recOperation = 0;
	recInvoke_id = 0;


	cout << endl << "*** Test Server Ready ***" << endl
		 << endl;

	if (manualMode)
	{
		char answer = 'n';
		cout << "Enter into Get Next y/n? : ";
		cin >> answer;
		while (answer == 'n' || answer == 'N')
		{
			char selection;
			selection = tolower(selection);
			cout << "***GetNext*** Pre Processing" << endl
				 << "Enter Selection:" << endl << endl
				 << "	P.	Print Counters" << endl
				 << "	S.	Reset Counters" << endl
				 << "	*.	Clean Up Dialogue" << endl 
				 << "	>.	Continue with Get Next" << endl
				 << "	X.	Exit one level" << endl << endl
				 << ">";
			cin >> selection;
			cout << endl;
			switch (selection)
			{
				case 'P':
					patsPrintCounters();
					break;
				case 'S':
					PegCountersReset();
					break;
				case '*':
					patsCleanUpDialogue();
					break;
				case '>':
					answer = 'y';
					break;
				case 'X':
					return;
				default:
					cout << "*** Invalid Selection ***" <<endl << endl;
			} /* switch */
		} /* while */
	} /* if */




	while (!stop)
	{
		cout << "[Server] Get Next Event " << endl;

		result = ITS_GetNextEvent(tcap_handle, &event.GetEvent());

        if (result != ITS_SUCCESS)
        {
            cout << "[Server] Failed to receive event: " << ITS_GetErrorText(result)
				 << endl;
            return;
        } /* if */

		if (TCAP_MSG_TYPE(&event.GetEvent()) == ITS_TCAP_DLG)
        {
			patsReceiveDialogue();
		} /* if */
		else if (TCAP_MSG_TYPE(&event.GetEvent()) == ITS_TCAP_CPT)
		{
			patsReceiveComponent();
		} /* else if */
	}  /* while */

	return;
} /* patsWaitOnEvent */

void
patsReceiveDialogue()
{
	int result = ITS_SUCCESS;

	if (pRecvDialogue != NULL)
	{
		delete pRecvDialogue;
		pRecvDialogue = NULL;
	} /* if */

	cout << "[Server] About to Receive Dialogue" << endl;

	result = TCAP_Dialogue::Receive(tcap_handle, event, &pRecvDialogue);

	if (result != ITS_SUCCESS)
	{
		cout << "[Server] Failed to receive TCAP Dialogue" << endl;
		return;
	} /* if */

	dialogue_id = pRecvDialogue->GetDialogueID();

	cout << "[Server] Received Dialogue Id <" 
		 << (int)dialogue_id 
		 <<">"
		 << endl;

	switch (pRecvDialogue->GetDialogueType())
	{
		case TCAP_PT_TC_UNI_CCITT:
			patsProcessUni();
			break;
		case TCAP_PT_TC_BEGIN_CCITT:
			patsProcessBegin();
			break;
		case TCAP_PT_TC_CONTINUE_CCITT:
			patsProcessContinue();
			break;
		case TCAP_PT_TC_END_CCITT:
			patsProcessEnd();
			break;
		case TCAP_PT_TC_P_ABORT_CCITT:
		case TCAP_PT_TC_U_ABORT_CCITT:
			patsProcessAbort();
			break;
		case TCAP_PT_TC_NOTICE_CCITT:
			patsProcessNotice();
			break;
		default:
			cout << "[Server] Received Dialogue we are not suppose to handle: "
				 << (int)pRecvDialogue->GetDialogueType() << endl;
			break;

	} /* switch */

} /* patsReceiveDialogue */

void
patsProcessUni()
{
	TCAP_Unidirectional* recvUni = static_cast<TCAP_Unidirectional*>(pRecvDialogue);

	recUniCtr++;
	uniRec = true;
	//
	// Fetching the Application context 

	ITS_OCTET recAppContextArray[100];
	int recAppContextArrayLen;

	long application_name=1, version=3;

	recvUni->GetDestAddr(AddressIndicatorDest, pcDest, ssnDest, &gttInfoDest, &gttLenDest);
	recvUni->GetOrigAddr(AddressIndicatorOrig, pcOrig, ssnOrig, &gttInfoOrig, &gttLenOrig);

	cout << "AddressIndicatorOrig <" << AddressIndicatorOrig 
		 << "> AddressIndicatorDest <" << AddressIndicatorDest << ">" << endl;

	cout << "pcOrig <" << (int)pcOrig << "> pcDest <" << (int)pcDest << ">" << endl;

	cout << "ssnOrig <" << (int)ssnOrig << "> ssnDest <" << (int)ssnDest << ">" << endl;


	recvUni->GetApplicationContext(recAppContextArray,
			                             recAppContextArrayLen);

	std::vector<byte> applicationContext(recAppContextArray,
					  recAppContextArray +
					  recAppContextArrayLen);


	for (int i = 0; i < applicationContext.size(); i++)
	{
		cout << "[Server] applicationContext at: " << (int)applicationContext.at(i) << endl;
	} /* if */


	cout << "[Server] Received TC_Unidirectional with "
		 << "dialogue id <" << (int)dialogue_id << ">"
		 << endl;

	if (!recvUni->IsComponentPresent())
	{
		cout << "[Server] TC_Unidirectional received with no component."
			 << endl;
		stop = true;
		return;
	} /* if */

} /* patsProcessUni */




void
patsProcessBegin()
{
	TCAP_Begin* recvBegin = static_cast<TCAP_Begin*>(pRecvDialogue);

	recBegCtr++;
	//
	// Fetching the Application context 

	ITS_OCTET recAppContextArray[100];
	int recAppContextArrayLen;

	long application_name=1, version=3;

	recvBegin->GetDestAddr(AddressIndicatorDest, pcDest, ssnDest, &gttInfoDest, &gttLenDest);
	recvBegin->GetOrigAddr(AddressIndicatorOrig, pcOrig, ssnOrig, &gttInfoOrig, &gttLenOrig);

	cout << "AddressIndicatorOrig <" << AddressIndicatorOrig 
		 << "> AddressIndicatorDest <" << AddressIndicatorDest << ">" << endl;

	cout << "pcOrig <" << (int)pcOrig << "> pcDest <" << (int)pcDest << ">" << endl;

	cout << "ssnOrig <" << (int)ssnOrig << "> ssnDest <" << (int)ssnDest << ">" << endl;


	recvBegin->GetApplicationContext(recAppContextArray,
			                             recAppContextArrayLen);

	std::vector<byte> applicationContext(recAppContextArray,
					  recAppContextArray +
					  recAppContextArrayLen);


	for (int i = 0; i < applicationContext.size(); i++)
	{
		cout << "[Server] applicationContext at: " << (int)applicationContext.at(i) << endl;
	} /* if */


	cout << "[Server] Received TC_Begin with "
		 << "dialogue id <" << (int)dialogue_id << ">"
		 << endl;

	if (!recvBegin->IsComponentPresent())
	{
		cout << "[Server] TC_Begin received with no component."
			 << endl;
		stop = true;
		return;
	} /* if */

} /* patsProcessBegin */


void
patsProcessContinue()
{
	recContCtr++;

	TCAP_Continue* recvContinue = static_cast<TCAP_Continue*>(pRecvDialogue);


	recvContinue->GetOrigAddr(AddressIndicatorOrig, pcOrig, ssnOrig, &gttInfoOrig, &gttLenOrig);

	cout << "AddressIndicatorOrig <" << AddressIndicatorOrig  << ">" << endl;

	cout << "pcOrig <" << (int)pcOrig <<  ">" << endl;

	cout << "ssnOrig <" << (int)ssnOrig << ">" << endl;

	dialogue_id = recvContinue->GetDialogueID();

	cout << "[Server] Received TC_Continue from Server dialogue id: <" 
		 << (int)dialogue_id << "> " << endl;

	if (!recvContinue->IsComponentPresent())
	{
		cout << "[Server] TC_Continue received with no component."
			 << endl;
		stop = true;
		return;
	} /* if */

	return;

} /* patsProcessContinue */



void
patsProcessEnd()
{
	TCAP_End* recvEnd = static_cast<TCAP_End*>(pRecvDialogue);

	recEndCtr++;

	cout << "[Server] Received TC_End from Client dialogue id: <" 
		 << (int)dialogue_id << "> " << endl;

	if (!recvEnd->IsComponentPresent())
	{
		cout << "[Server] TC_End received with no component."
			 << endl;
		stop = true;
		dialogue_id = 0;	/* dialogue context was terminated by stack */
		return;
	} /* if */


	return;

} /* patsProcessEnd */



void
patsProcessNotice()
{
	TCAP_Notice* recvNotice = static_cast<TCAP_Notice*>(pRecvDialogue);

	recNotCtr++;

	ITS_OCTET returnCause = recvNotice->GetReportCause();

	cout << "[Server] Received SCCP Notice <" <<
		(int)notice_returnCause[returnCause] << 
		"> for dialogue id <" << (int)dialogue_id << ">" << endl;

	patsCleanUpDialogue();

	return;

} /* ProcessNotice */

void
patsProcessAbort()
{
	stop = true;

	recUAbortCtr++;

	TCAP_Abort* recvAbort = static_cast<TCAP_Abort*>(pRecvDialogue);

	// (Values defined in tcap.h)
	recReason = recvAbort->GetAbortReason();

	if (recvAbort->GetDialogueType() == TCPPT_TC_P_ABORT)
	{
		// The TCAP stack at the Client found something wrong.
		cout << "[Server] Received TC_P_Abort <" <<
			    (int)abort_pabortReason[recReason] << 
			    "> for dialogue id <" << (int)dialogue_id << ">" << endl;

		return;
	} /* if */


	// if we are here, the Server itself aborted the TCAP transaction
	switch (recReason)
	{
		case TCAP_UABT_AC_NOT_SUP_CCITT:
		{
					
			ITS_OCTET applicationContextArray[100];
			int applicationContextArrayLen;

		cout << "[Server] Received TC_U_Abort dialogue "
			 << "Application Context not supported TCAP_UABT_AC_NOT_SUP_CCITT <" << (int)dialogue_id
			 << ">" << endl;

			recvAbort->GetApplicationContext(applicationContextArray,
		                         applicationContextArrayLen);

			std::vector<byte>
					applicationContext(applicationContextArray,
					                   applicationContextArray +
									   applicationContextArrayLen);

			for (int i = 0; i < applicationContext.size(); i++)
			{
				cout << "[Server] applicationContext at: " << (int)applicationContext.at(i) << endl;
			} /* if */
		} /* case */
		break;

	case TCAP_UABT_DLG_REFUSED_CCITT:
		cout << "[Server] Received TC_U_Abort dialogue "
			 << "was refused for dialogue id "
			 << "TCAP_UABT_DLG_REFUSED_CCITT <" << (int)dialogue_id
			 << ">" << endl;
		//
		// It might be possible that the User Information parameter
		// explained the reason.
		//
		break;

	case TCAP_UABT_USER_DEFINED_CCITT:
		cout << "[Server] Received TC_U_Abort - "
			 << "Server aborted operation for user defined reason,"
			 << " TCAP_UABT_USER_DEFINED_CCITT for dialogue id <"
			 << (int)dialogue_id << ">" << endl;

		//
		// It might be possible that the User Information parameter
		// explained the reason.
		//
		break;
	} /* switch */

	//
	// There is no component associated with TC_Abort.
	// Upon reception of the TC_Abort, the TCAP stack
	// automatically deleted the dialogue id for us.
	//

	return;

} /* ProcessAbort */



void
patsReceiveComponent()
{
	int result = ITS_SUCCESS;

	if (pRecvComponent != NULL)
	{
		delete pRecvComponent;
		pRecvComponent = NULL;
	} /* if */

	cout << "[Server] About to Receive Component" << endl;


	result = TCAP_Component::Receive(tcap_handle, event, pRecvDialogue,
											 &pRecvComponent);

	if (result != ITS_SUCCESS)
	{
	//
	// We fail to receive the component.
	//
	cout << "[Server] Failed to receive TCAP Component" << endl;

	return;
	} /* if */

	switch (pRecvComponent->GetComponentType())            
	{
		case TCAP_PT_TC_INVOKE_CCITT:
			patsProcessInvoke();
			break;
		case TCAP_PT_TC_RESULT_NL_CCITT:
		case TCAP_PT_TC_RESULT_L_CCITT:
			patsProcessResult();
			break;
		case TCAP_PT_TC_U_ERROR_CCITT:
			patsProcessError();
			break;
		case TCAP_PT_TC_R_REJECT_CCITT:
		case TCAP_PT_TC_L_REJECT_CCITT:
		case TCAP_PT_TC_U_REJECT_CCITT:
			patsProcessReject();
			break;
		case TCAP_PT_TC_L_CANCEL_CCITT:
		case TCAP_PT_TC_U_CANCEL_CCITT:
			patsProcessCancel();
			break;
		case TCAP_PT_TC_TIMER_RESET_CCITT:
		default:
			cout << "[Server] Unprepaired for this type component" << endl;
			break;
	} /* switch */

	return;
} /* patsReceiveComponent */

void
patsProcessInvoke()
{
	recInvCtr++;

	TCAP_Invoke* recvInvokeCpt = static_cast<TCAP_Invoke*> (pRecvComponent);
			
	recInvoke_id = recvInvokeCpt->GetInvokeID();

	recvInvokeCpt->GetOperation(recOperation);

	recvInvokeCpt->GetParameter(recParm);

	if (recParm.empty())
	{
		cout << "[Server] Received Invoke with no parms did: <"
			<< (int)dialogue_id << ">, inv id: " << (int) recInvoke_id
			<< "> Operation <" << (int)recOperation  << endl;
	} /* if */
	else
	{
		cout << "[Server] Received Invoke with  did: <"
			 << (int)dialogue_id << ">, inv id: " << (int) recInvoke_id
			 << "> Operation <" << (int)recOperation  << endl;

		for (int i = 0; i < recParm.size(); i++)
		{
			cout << "[Server] recParm at: " << (int)recParm.at(i) << endl;
		} /* if */

	} /* else */


    // Last component?
	if (!pRecvComponent->GetLast())
	{
		cout << "[Server] This not the last component." << endl;
	} /* if */
	else
	{
		stop = true;	
	} /* else */

	if (pRecvDialogue != NULL)
    {
        delete pRecvDialogue;
        pRecvDialogue = NULL;
    } /* if */

    if (pRecvComponent != NULL)
    {
        delete pRecvComponent;
        pRecvComponent = NULL;
    } /* if */


	return;

} /* patsProcessInvoke */
 

void
patsProcessResult()
{
	string cptTypeTxt; 

	TCAP_Result* recvResult =
		static_cast<TCAP_Result*>(pRecvComponent);

	ITS_OCTET cptType = pRecvComponent->GetComponentType();

	if (cptType == TCAP_PT_TC_RESULT_NL_CCITT)
	{
		recResNLCtr++;
		cptTypeTxt.append("NL");
	}
	else
	{
		recResCtr++;
		cptTypeTxt.append("NL");
	} /* else */

	recInvoke_id = recvResult->GetInvokeID();


	try
	{
		recvResult->GetOperation(recOperation);

	} /* try */

	catch (ITS_GenericException& exception)
	{
		cout << "[Server] Received empty Result " << cptTypeTxt << " from Server did: <"
			 << (int)dialogue_id << ">, inv id: <" << (int) recInvoke_id
			 << ">" << endl;

		return;
	} /* catch */		


	recParm.clear();

	recvResult->GetParameter(recParm);

	if (recParm.empty())
	{
		cout << "[Server] Received Result from Client with no data?"
			 <<" result did: <" << (int)dialogue_id << ">, invoke id: <"
			 << (int) recInvoke_id << ">, operation: <"  << recOperation 
			 << ">" << endl;
	} /* if */
	else
	{
		cout << "[Server] Received Result from Client "
			 <<" result did: <" << (int)dialogue_id << ">, invoke id: <"
			 << (int) recInvoke_id << ">, operation: <"  << recOperation 
			 << ">" << endl;

		for (int i = 0; i < recParm.size(); i++)
		{
			cout << "[Server] recParm at: " << (int)recParm.at(i) << endl;
		} /* if */
	} /* else */


	if (!recvResult->GetLast())
	{
		cout << "[Server] This is not the last component. "	 << endl;
	} /* if */
	else
	{
		stop = true;
	} /* else - no more components */

	return;
} /* patsProcessResult */




void
patsProcessError()
{
	TCAP_Error* recvError =
			static_cast<TCAP_Error*>(pRecvComponent);

	recErrCtr++;

	recInvoke_id = recvError->GetInvokeID();
					
	recvError->GetError(recCode);



	cout << "[Server] Received Error from Server did: <"
		 << (int)dialogue_id << ">, inv id: <" << (int) recInvoke_id
		 << ">, error: <" << (int) recCode << ">"  << endl;


	if (!recvError->GetLast())
	{
		cout << "[Server] This is not the last component. "	 << endl;
	} /* if */
	else
	{
		stop = true;
	} /* else - no more components */


	return;

} /* patsProcessError */


void
patsProcessReject()
{
	//
	ITS_OCTET type = 0;
	ITS_OCTET code = 0;
	string recRejectTypeTxt;


	TCAP_Reject* recvReject =
		static_cast<TCAP_Reject*>(pRecvComponent);

	recRejCtr++;


	recInvoke_id = recvReject->GetInvokeID();

	recvReject->GetProblem(type, code);

	switch(recvReject->GetComponentType())
	{
		case TCAP_PT_TC_R_REJECT_CCITT:
			recErrorTxt.append("Remote Stack at Client");
			break;
		case TCAP_PT_TC_L_REJECT_CCITT:
			recErrorTxt.append("Local Stack at Server");
			break;
		case TCAP_PT_TC_U_REJECT_CCITT:
			recErrorTxt.append("Remote User at Client");
			break;
	} /* switch */


	cout << "[Server] Received Reject from" << recErrorTxt << "did: <"
		 << (int)dialogue_id << ">, inv id: <" << (int) recInvoke_id
		 << ">, type: <" << (int) type << ">, code: <" << (int) code
		 << ">" << endl;

	switch (type)
	{
		case TCAP_PROB_GENERAL_CCITT:
			ptbl = (PTAGTBL) &grptbl_rejCodeResGroup[0];
		case TCAP_PROB_INVOKE_CCITT:
			ptbl = (PTAGTBL) &grptbl_rejCodeGenGroup[0];
		case TCAP_PROB_RETURN_RES_CCITT:
			ptbl = (PTAGTBL) &grptbl_rejCodeInvGroup[0];
		case TCAP_PROB_RETURN_ERR_CCITT:
			ptbl = (PTAGTBL) &grptbl_rejCodeErrGroup[0];
	} /* switch */

	for(int i = 0; (ptbl+i)->pname != (char *)-1; i++)
	{
		if((ptbl+i)->id == code)
		{
			break;
		} /* if */
	} /* for */

	if ((ptbl+i)->pname != (char *)-1)
	{
		cout << "Rejection Received <" << (char *)((ptbl+i)->pname) << ">" << endl;
	} /* if */


	if (!recvReject->GetLast())
	{
		cout << "[Server] This is not the last component. "	 << endl;
	} /* if */
	else
	{
		stop = true;
	} /* else - no more components */


	return;

} /* patsProcessReject */



void
patsProcessCancel()
{
	//
	// We receive a TC_LocalCancel, application must decide what to
	// do. Application must release the dialogue id (since application
	// is not allowed to send a new TC_Invoke or TC_Begin in the state
	// of the current dialogue id).
	//
	recCanCtr++;

	cout <<"[Server] Any Time Interrogation operation timed out," <<
		   "releasing dialogue id <" << (int)dialogue_id <<">" << endl;

	patsCleanUpDialogue();

	return;
} /* patsProcessCancel */


void
patsBuildContinue()
{
	sntContCtr++;

	cout << "[Server] About to Build Continue Dialogue Id <"
		 << dialogue_id << "> Destination Address from received Dialogue is used as Origin as follows" << endl;

	cout << "AddressIndicatorOrig <" << AddressIndicatorDest  << ">" << endl;

	cout << "pcOrig <" << (int)pcDest <<  ">" << endl;

	cout << "ssnOrig <" << (int)ssnDest << ">" << endl;


	//
	// Setting the Dialogue id obtained from TC_Begin received from Client.
	//

	TC_Continue.SetDialogueID(dialogue_id);
	TC_Continue.SetOrigAddr(AddressIndicatorDest, pcDest, ssnDest, NULL, 0);


	pTC_Dialogue = static_cast<TCAP_Dialogue*>(&TC_Continue);

	return;

} /* patsBuildContinue */




void
patsBuildEnd()
{
	sntEndCtr++;

	cout << "[Server] About to Build End Dialogue Id <" << dialogue_id << ">" << endl;


	//
	// Setting the Dialogue id obtained from TC_Begin received from Client.
	//

	TC_End.SetDialogueID(dialogue_id);

	//
	// Setting Application Context 
	//


	sntAppContext.clear();

	sntAppContext.push_back(3);
	
	sntAppContext.push_back(1);

	sntAppContext.push_back(3);


	TC_End.SetApplicationContext(&sntAppContext[0],
		                         sntAppContext.size());

	pTC_Dialogue = static_cast<TCAP_Dialogue*>(&TC_End);

	return;

} /* patsBuildEnd */


void
patsBuildUAbort()
{
	sntUAbortCtr++;

	cout << "[Server] About to Build U Abort Dialogue Id <" << dialogue_id << ">" << endl;
	//
	// Setting the Dialogue id obtained from TC_Begin received from Client.
	//

	TC_Abort.SetDialogueID(dialogue_id);

	;
	//
	// Setting the Dialogue id obtained from TC_Begin received from Client.
	//
	ITS_OCTET reason = reasontbl[reasonIndex%3].reason;
	reasonIndex++;

	cout << "[Server] About to Build U Abort Dialogue reason <" 
		 << (int)reason << ">"<< endl;

	for(int i = 0; grptbl_reasonUABTGroup[i].pname != (char *)-1; i++)
	{
		if(grptbl_reasonUABTGroup[i].id == reason)
		{
			break;
		} /* if */
	} /* for */

	if (grptbl_reasonUABTGroup[i].pname != (char *)-1)
	{
		cout << "UAbort to be sent with reason <" << (char *)(grptbl_reasonUABTGroup[i].pname) << ">" << endl;
	} /* if */

	TC_Abort.SetAbortReason(reason);
	
	//
	// Setting Application Context "obtained" from TC_Begin received
	// from Client.
	//

	sntAppContext.clear();

	sntAppContext.push_back(1);
	
	sntAppContext.push_back(1);

	sntAppContext.push_back(1);



	TC_Abort.SetApplicationContext(&sntAppContext[0],
		                         sntAppContext.size());

	pTC_Dialogue = static_cast<TCAP_Dialogue*>(&TC_Abort);

} /* patsBuildUAbort */


void
patsBuildInvoke()
{
	sntInvCtr++;

	cout << "[Server] Build Invoke with id <" << (int)sntInvoke_id 
		 << "> Linked Invoke Id: <" << (int)recInvoke_id
		 << "> Operation: <" << (int)sntOperation << ">" << endl;

	TC_Invoke.SetInvokeID(sntInvoke_id++);

	TC_Invoke.SetOperation(sntOperation++);

	if (recInvoke_id != 0)
	{
		TC_Invoke.SetLinkedID(recInvoke_id);
	} /* if */

	if (operationClass >= 5)
	{
		operationClass = 1;
	} /* if */

	TC_Invoke.SetClass(operationClass++);

	TC_Invoke.SetTimeOut(300);

	sntParm.clear();

	sntParm.push_back(1);	// Tag
	
	sntParm.push_back(1);	// Length

	sntParm.push_back(1);	// Data

	TC_Invoke.SetParameter(sntParm);

	pTC_Component = static_cast<TCAP_Component*>(&TC_Invoke);

	return;

} /* patsBuildInvoke */

void
patsBuildCancel()
{

	sntCanCtr++;

	cout << "[Client] Build Cancel with id <" << (int)sntInvoke_id << ">" << endl;

	TC_Cancel.SetInvokeID(sntInvoke_id);

	pTC_Component = static_cast<TCAP_Component*>(&TC_Cancel);


	return;

} /* patsBuildCancel */

void
patsBuildResult()
{
	sntResCtr++;

	if (notLast)
	{
		notLast = false;
		recOperation = saveOperation;
		recInvoke_id = saveInvoke_id;
	} /* if */

	cout << "[Server] Build Result-L with id <" << (int)recInvoke_id 
		 		 << "> Operation: <" << (int)recOperation << ">" << endl;


	// Set invoke id obtained from TC_Invoke received from Client.
	//
	TC_Result.SetInvokeID(recInvoke_id);

	if (recOperation != 0)
	{
		//
		// Set operation code.
		//
		TC_Result.SetOperation(recOperation);

		sntParm.clear();

		sntParm.push_back(2);	// Tag
	
		sntParm.push_back(1);	// Length

		sntParm.push_back(1);	// Data


		if (!sntParm.empty())	// currently always not empty
		{
			//
			// Set Parameters.
			//

			TC_Result.SetParameter(sntParm);
		} /* if */

		pTC_Component = static_cast<TCAP_Component*>(&TC_Result);
	} /* if */
	else
	{
		cout << "Received Operation not valid -- No Result-L component built" << endl;
	} /* else */



	return;

} /* patsBuildResult */

void
patsBuildResult_NL()
{
	sntResNLCtr++;

	if (!notLast)
	{
		notLast = true;
		saveOperation = recOperation;
		saveInvoke_id = recInvoke_id;
	} /* if */
	else
	{
		recOperation = saveOperation;
		recInvoke_id = saveInvoke_id;
	} /* else */
		

	cout << "[Server] Build Result NL with id <" << (int)recInvoke_id 
		 		 << "> Operation: <" << (int)recOperation << ">" << endl;


	// Set invoke id obtained from TC_Invoke received from Client.
	//
	TC_Result_NL.SetInvokeID(recInvoke_id);

	if (recOperation != 0)
	{
		//
		// Set operation code.
		//
		TC_Result_NL.SetOperation(recOperation);

		sntParm.clear();

		sntParm.push_back(2);	// Tag
	
		sntParm.push_back(1);	// Length

		sntParm.push_back(1);	// Data


		if (!sntParm.empty())	// currently always not empty
		{
			//
			// Set Parameters.
			//

			TC_Result_NL.SetParameter(sntParm);
		} /* if */

		pTC_Component = static_cast<TCAP_Component*>(&TC_Result_NL);
	} /* if */
	else
	{
		cout << "Received Operation not valid -- No Result-NL component built" << endl;
	} /* else */

	return;

} /* patsBuildResult_NL */



void
patsBuildError()
{
	sntErrCtr++;

	cout << "[Server] About to Build Error Component" << endl
		 << "Invoke Id <" << (int)recInvoke_id << ">, Errror Code <"
		 << (int)sntErrorCode << ">" << endl;

	//
	// Set invoke id obtained from TC_Invoke received from Client.
	//
	
	TC_Error.SetInvokeID(recInvoke_id);

	//
	// Set error
	//
	TC_Error.SetError(sntErrorCode++);

	pTC_Component = static_cast<TCAP_Component*>(&TC_Error);

	return;
} /* patsBuildError */



void
patsBuildReject()
{
PTAGTBL ptbl;

	sntRejCtr++;

	//
	// Set invoke id obtained from TC_Reject received from Client.
	//
	ITS_OCTET problem = rejtbl[rejIndex%19].type;
	ITS_OCTET code = rejtbl[rejIndex%19].code;
	rejIndex++;
	
	cout << "[Server] About to Build Reject Component" << endl
		 << "Invoke Id <" << (int)recInvoke_id << ">, Problem <"
		 << (int)problem << ">, Code <" << (int)code << ">" << endl;;


	switch (problem)
	{
		case TCAP_PROB_GENERAL_CCITT:
			ptbl = (PTAGTBL) &grptbl_rejCodeResGroup[0];
		case TCAP_PROB_INVOKE_CCITT:
			ptbl = (PTAGTBL) &grptbl_rejCodeGenGroup[0];
		case TCAP_PROB_RETURN_RES_CCITT:
			ptbl = (PTAGTBL) &grptbl_rejCodeInvGroup[0];
		case TCAP_PROB_RETURN_ERR_CCITT:
			ptbl = (PTAGTBL) &grptbl_rejCodeErrGroup[0];
	} /* switch */

	for(int i = 0; (ptbl+i)->pname != (char *)-1; i++)
	{
		if((ptbl+i)->id == code)
		{
			break;
		} /* if */
	} /* for */

	if ((ptbl+i)->pname != (char *)-1)
	{
		cout << "Rejection to be sent <" << (char *)((ptbl+i)->pname) << ">" << endl;
	} /* if */



	TC_Reject.SetInvokeID(recInvoke_id);

    //
    // Set operation code.
	//
    TC_Reject.SetProblem(problem, code);

	pTC_Component = static_cast<TCAP_Component*>(&TC_Reject);

	return;
} /* patsBuildReject */

bool
patsSendComponent()
{
	ITS_OCTET theInvoke_id, type, code;
	ITS_LONG operation;
	ITS_USHORT theDialogue_Id;
	string printTxt;
	char txt[3];
	int result = ITS_SUCCESS;

	cout << "[Server] About to Send Component" << endl;

	if (pTC_Component == NULL  || pTC_Dialogue == NULL)
	{
		cout << "Either pTC_Component <" << (int)pTC_Component <<"> or pTC_Dialogue <"
			 << pTC_Dialogue << "> are Null" << endl;
		return false;
	} /* if */
	
	theDialogue_Id = pTC_Dialogue->GetDialogueID();


	theInvoke_id = pTC_Component->GetInvokeID();

	switch (pTC_Component->GetComponentType())            
	{
		case TCAP_PT_TC_INVOKE_CCITT:
			printTxt.append("Invoke Component Invoke_Id <");
			_itoa(theInvoke_id, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Operation <");
			 static_cast<TCAP_Invoke*>(pTC_Component)->GetOperation(operation);
			_itoa(operation, txt, 10);
			printTxt.append(txt);
			printTxt.append("> ");
			break;
		case TCAP_PT_TC_RESULT_NL_CCITT:
			printTxt.append("Result NL Invoke_Id <");
			_itoa(theInvoke_id, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Operation <");
			 static_cast<TCAP_Result*>(pTC_Component)->GetOperation(operation);
			_itoa(operation, txt, 10);
			printTxt.append(txt);
			printTxt.append("> ");
			break;
		case TCAP_PT_TC_RESULT_L_CCITT:
			printTxt.append("Result NL Invoke_Id <");
			_itoa(theInvoke_id, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Operation <");
			 static_cast<TCAP_Result*>(pTC_Component)->GetOperation(operation);
			_itoa(operation, txt, 10);
			printTxt.append(txt);
			printTxt.append("> ");
			break;
		case TCAP_PT_TC_U_ERROR_CCITT:
			printTxt.append("Error Invoke_Id <");
			_itoa(theInvoke_id, txt, 10);
			printTxt.append(txt);
			printTxt.append("> ");
			break;
		case TCAP_PT_TC_R_REJECT_CCITT:
			printTxt.append(" R Reject Invoke_Id <");
			_itoa(theInvoke_id, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Type <");
			static_cast<TCAP_Reject*>(pTC_Component)->GetProblem(type, code);
			_itoa(type, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Code <");
			_itoa(type, txt, 10);
			printTxt.append(txt);
			printTxt.append("> ");
			break;
		case TCAP_PT_TC_L_REJECT_CCITT:
			printTxt.append("L Reject Invoke_Id <");
			_itoa(theInvoke_id, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Type <");
			static_cast<TCAP_Reject*>(pTC_Component)->GetProblem(type, code);
			_itoa(type, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Code <");
			_itoa(type, txt, 10);
			printTxt.append(txt);
			printTxt.append("> ");
			break;
		case TCAP_PT_TC_U_REJECT_CCITT:
			printTxt.append("U Reject Invoke_Id <");
			_itoa(theInvoke_id, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Type <");
			static_cast<TCAP_Reject*>(pTC_Component)->GetProblem(type, code);
			_itoa(type, txt, 10);
			printTxt.append(txt);
			printTxt.append("> Code <");
			_itoa(type, txt, 10);
			printTxt.append(txt);
			printTxt.append("> ");
			break;
		case TCAP_PT_TC_L_CANCEL_CCITT:
			printTxt.append("L Cancel ");
			break;
		case TCAP_PT_TC_U_CANCEL_CCITT:
			printTxt.append("U Cancel ");
			break;
		case TCAP_PT_TC_TIMER_RESET_CCITT:
			printTxt.append("Timer Reset ");
			break;
	} /* switch */

	cout << "Dialogue Id <" << theDialogue_Id << ">" << printTxt << endl;




    result = TCAP_Component::Send(tcap_handle, pTC_Dialogue, pTC_Component);


	if (result != ITS_SUCCESS)
	{
		cout << "[Client] Send Component Failed: <"
			 << ITS_GetErrorText(result) << ">" << endl;

		patsCleanUpDialogue();

		return false;

	} /* if */


	pTC_Component = NULL;

	return true;

} /* patsSendComponent */


bool
patsSendDialogue()
{
	cout << "[Server] About to Send Dialogue" << endl;

	if (pTC_Dialogue == NULL)
	{
		return false;
	} /* if */

	if (TCAP_Dialogue::Send(tcap_handle, pTC_Dialogue) != ITS_SUCCESS)
	{
		return false;
	}
	return true;

} /* patsSendDialogue */




void
patsCleanUpDialogue()
{
	int result = ITS_SUCCESS;

	cout << "[Server] PreArrangedEnd" << endl;

	TCAP_End TC_End;

	TC_End.SetPreArrangedEnd(true);

	TC_End.SetDialogueID(dialogue_id);

	TCAP_Dialogue::Send(tcap_handle, &TC_End);

	// Delete allocated memory
	if (pRecvDialogue != NULL)
	{
		delete pRecvDialogue;
		pRecvDialogue = NULL;
	} /* if */
				
	if (pRecvComponent != NULL)
	{
		delete pRecvComponent;
		pRecvComponent = NULL;
	} /* if */

	// Application is done with this dialogue message
	stop = true;
	dialogue_id = 0;

	return;

} /* patsCleanUpDialogue */





void
patsPrintCounters()
{
	int group=1, i=1, i2=1, *pi=&i, ti=1, ret;

	PegGetCounter_CCITT(3, TCAP_PT_TC_INVOKE_CCITT, pmytheCounters);
	ptbl = (PTAGTBL) tblptrs[3].ptbl;

	for (ti=1; ti<90; ti++)
	{
		if (ptbl[ti].id == TCAP_PT_TC_INVOKE_CCITT) break;
	} /* if */


	printf ("\nMsgType = %d %s\n", pmytheCounters->cntName, (char *)ptbl[ti].pname);
	printf ("rec %d snt %d discard %d \n\n\n",
		pmytheCounters->u.m.msg_received, pmytheCounters->u.m.msg_sent, 
		pmytheCounters->u.m.msg_discarded);

	for (group = msgGroup; group <= rejCodeTransGroup; group++)
	{
		printf("Group < %d > \n", group);

		for (i = 1;;)
		{
			ret = PegGetNextCounter_CCITT(group, pi, pmytheCounters);
			if (ret == -1) 
			{
				printf("Break on error\n");
				break;	// exit on error
			} /* if */
			if (*pi == -1) 
			{
				printf ("Break on EOF\n");
				break;	// exit on EOF
			} /* if */

			ptbl = (PTAGTBL) tblptrs[group].ptbl;

			if (pmytheCounters->cntName != 0)
			{
				for (ti=0; ti<90; ti++)
				{
					if (ptbl[ti].id == pmytheCounters->cntName) 
					{
						break;
					} /* if */
				} /* for */
			} /* if */
			if (group == reasonUABTGroup || group == reasonPABTGroup)
			{
				printf ("\nMsgType = %d %s\n", pmytheCounters->cntName, (char *)ptbl[ti].pname);
				if (pmytheCounters->cntName != 0)
				{
					printf ("Received from Remote %d Sent to Remote %d Sent to App %d \n", 
						pmytheCounters->u.o.ot_received, pmytheCounters->u.o.ot_sentTOremote, 
						pmytheCounters->u.o.ot_sentTOapp);

				} /* if */
			} /* if */
			else
			{
				printf ("\nMsgType = %d %s\n", pmytheCounters->cntName, (char *)ptbl[ti].pname);
				if (pmytheCounters->cntName != 0)
				{
					printf ("rec %d snt %d discard %d \n", 
						pmytheCounters->u.m.msg_received, pmytheCounters->u.m.msg_sent, 
						pmytheCounters->u.m.msg_discarded);
				} /* if */
			} /* else */
		} /* for - EOF or Error */
	} /* for - first 11 groups */

	group = miscGroup;

	printf("Group < %d > \n", group);

	for (i = 1;;)
	{
		ret = PegGetNextCounter_CCITT(group, pi, pmymiscCounters);
		if (ret == -1) 
		{
			printf("Break on error\n");
			break;	// exit on error
		} /* if */
		if (*pi == -1) 
		{
			printf ("Break on EOF\n");
			break;	// exit on EOF
		} /* if */

		ptbl = (PTAGTBL) tblptrs[group].ptbl;

		if (pmymiscCounters->cntName != 0)
		{
			for (ti=0; ti<90; ti++)
			{
				if (ptbl[ti].id == pmymiscCounters->cntName) 
				{
					break;
				} /* if */
			} /* for */
		} /* if */


		printf ("\nMsgType = %d %s\n", pmymiscCounters->cntName, (char *)ptbl[ti].pname);
		if (pmymiscCounters->cntName != 0)
		{
			printf ("Count %d \n", 	pmymiscCounters->cnt);
		} /* if */
	} /* for - EOF or Error */

	cout << "sntBegCtr <" << sntBegCtr << "> sntContCtr <"<< sntContCtr << ">" << endl
	<< "sntEndCtr <" << sntEndCtr << "> sntUAbortCtr <" << sntUAbortCtr << ">" << endl
	<< "sntNotCtr <" << sntNotCtr << ">" << endl
	<< "recBegCtr <" << recBegCtr << "> recContCtr <" << recContCtr  << ">" << endl
	<< "recEndCtr <" << recEndCtr << "> recUAbortCtr <" << recUAbortCtr << ">" << endl
	<< "recNotCtr <" << recNotCtr << ">" << endl
	<< "sntInvCtr <" << sntInvCtr << "> sntResCtr <" << sntResCtr << ">" << endl
	<< "sntErrCtr <" << sntErrCtr << "> sntRejCtr <" << sntRejCtr << ">" << endl
	<< "recInvCtr <" << recInvCtr << "> recResCtr <" << recResCtr << ">" << endl 
	<< "recErrCtr <" << recErrCtr << "> recRejCtr <" << recRejCtr << ">" << endl
	<< "recResNLCtr <" << recResNLCtr << "> sntResNLCtr <" << sntResNLCtr << endl;

} /* patsPrintCounters */